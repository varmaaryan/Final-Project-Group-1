import os
import ast
import inspect
import networkx as nx

class CohesionAnalyzer:
    def __init__(self, file_path):
        self.file_path = file_path
        self.classes = self._extract_classes()

    def _extract_classes(self):
        """
        Extract classes from a Python file without importing
        """
        classes = []
        try:
            with open(self.file_path, 'r', encoding='utf-8') as file:
                tree = ast.parse(file.read())
            
            # Find class definitions
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    classes.append(node)
            
            return classes
        except Exception as e:
            print(f"Error parsing {self.file_path}: {e}")
            return []

    def calculate_lcom4(self, class_node):
        """
        Estimate LCOM4 by analyzing method interactions in the AST
        """
        method_nodes = [node for node in class_node.body if isinstance(node, ast.FunctionDef)]
        
        # Create a graph to track method interactions
        G = nx.Graph()
        
        # Add method names as nodes
        for method in method_nodes:
            G.add_node(method.name)
        
        # Analyze attribute and method interactions
        for i, method1 in enumerate(method_nodes):
            for method2 in method_nodes[i+1:]:
                # Check for shared attribute references
                if self._methods_interact(method1, method2):
                    G.add_edge(method1.name, method2.name)
        
        # Count connected components
        try:
            components = list(nx.connected_components(G))
            return len(components)
        except:
            return len(method_nodes)

    def _methods_interact(self, method1, method2):
        """
        Check if two methods interact based on AST analysis
        """
        # Collect attributes accessed in methods
        def collect_attributes(method_node):
            attributes = set()
            for node in ast.walk(method_node):
                if isinstance(node, ast.Attribute):
                    attributes.add(node.attr)
            return attributes
        
        # Compare attribute sets
        attr1 = collect_attributes(method1)
        attr2 = collect_attributes(method2)
        
        return len(attr1 & attr2) > 0

    def calculate_functional_cohesion(self, class_node):
        """
        Estimate functional cohesion based on method signatures
        """
        method_nodes = [node for node in class_node.body if isinstance(node, ast.FunctionDef)]
        
        # Track method parameter similarities
        cohesion_score = 0
        total_comparisons = 0
        
        for i, method1 in enumerate(method_nodes):
            for method2 in method_nodes[i+1:]:
                # Compare method parameters
                params1 = {arg.arg for arg in method1.args.args}
                params2 = {arg.arg for arg in method2.args.args}
                
                # Calculate parameter overlap
                shared_params = params1 & params2
                cohesion_score += len(shared_params)
                total_comparisons += 1
        
        # Normalize the score
        return cohesion_score / total_comparisons if total_comparisons > 0 else 0

class CouplingAnalyzer:
    def __init__(self, project_path):
        self.project_path = project_path
        self.module_dependencies = self._analyze_dependencies()

    def _analyze_dependencies(self):
        """
        Analyze dependencies between modules using AST
        """
        dependencies = {}

        for root, _, files in os.walk(self.project_path):
            for file in files:
                if file.endswith('.py'):
                    file_path = os.path.join(root, file)
                    module_name = os.path.relpath(file_path, self.project_path).replace(os.sep, '.')[:-3]

                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            tree = ast.parse(f.read())
                        
                        imports = set()
                        for node in ast.walk(tree):
                            if isinstance(node, ast.Import):
                                for alias in node.names:
                                    imports.add(alias.name)
                            elif isinstance(node, ast.ImportFrom):
                                if node.module:
                                    imports.add(node.module)
                        
                        dependencies[module_name] = imports
                    except Exception as e:
                        print(f"Error analyzing {file_path}: {e}")

        return dependencies

    def calculate_coupling(self):
        """
        Calculate fan-in and fan-out for modules
        """
        fan_in = {}
        fan_out = {}

        for module, imports in self.module_dependencies.items():
            fan_out[module] = len(imports)
            for imported in imports:
                fan_in[imported] = fan_in.get(imported, 0) + 1

        return fan_in, fan_out

def analyze_project_cohesion(project_path):
    """
    Analyze cohesion across a project without importing
    """
    cohesion_results = {}
    
    for root, dirs, files in os.walk(project_path):
        dirs[:] = [d for d in dirs if d not in ['venv', '.venv', 'env', 'tests', '__pycache__']]
        
        for file in files:
            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                
                try:
                    analyzer = CohesionAnalyzer(file_path)
                    
                    for class_node in analyzer.classes:
                        class_name = class_node.name
                        
                        lcom4 = analyzer.calculate_lcom4(class_node)
                        func_cohesion = analyzer.calculate_functional_cohesion(class_node)
                        
                        cohesion_results[f"{file}:{class_name}"] = {
                            'LCOM4': lcom4,
                            'Functional Cohesion': func_cohesion
                        }
                except Exception as e:
                    print(f"Error analyzing {file_path}: {e}")

    return cohesion_results

def analyze_project(project_path):
    cohesion_results = analyze_project_cohesion(project_path)
    coupling_analyzer = CouplingAnalyzer(project_path)
    fan_in, fan_out = coupling_analyzer.calculate_coupling()

    coupling_results = {
        'Fan-In': fan_in,
        'Fan-Out': fan_out
    }

    return cohesion_results, coupling_results

def main(project_path):
    cohesion_results, coupling_results = analyze_project(project_path)

    # Count modules analyzed for cohesion
    total_modules = len(cohesion_results)

    # Calculate high and low cohesion counts
    high_cohesion_count = sum(
        1 for metrics in cohesion_results.values() if metrics['LCOM4'] <= 2 and metrics['Functional Cohesion'] >= 0.3
    )
    low_cohesion_count = total_modules - high_cohesion_count

    # Count modules analyzed for coupling
    total_fan_in_modules = len(coupling_results['Fan-In'])
    total_fan_out_modules = len(coupling_results['Fan-Out'])

    report = "PROJECT COHESION AND COUPLING AND MODULE COUNT ANALYSIS\n"
    report += "===============================\n\n"

    report += "Cohesion Analysis:\n\n"
    for module, metrics in cohesion_results.items():
        report += f"Module: {module}\n"
        report += f"LCOM4 (Lower is better): {metrics['LCOM4']}\n"
        report += f"Functional Cohesion (Higher is better): {metrics['Functional Cohesion']:.4f}\n\n"

    report += "\nCoupling Analysis:\n\n"
    report += "Fan-In:\n"
    for module, count in coupling_results['Fan-In'].items():
        report += f"{module}: {count}\n"

    report += "\nFan-Out:\n"
    for module, count in coupling_results['Fan-Out'].items():
        report += f"{module}: {count}\n"

    # Add Summary Section
    report += "\nSummary:\n"
    report += f"Total Modules Analyzed for Cohesion: {total_modules}\n"
    report += f"High Cohesion Modules: {high_cohesion_count}\n"
    report += f"Low Cohesion Modules: {low_cohesion_count}\n"
    report += f"Total Modules with Fan-In Data: {total_fan_in_modules}\n"
    report += f"Total Modules with Fan-Out Data: {total_fan_out_modules}\n"

    print(report)
    with open('analysis_report.txt', 'w', encoding='utf-8') as f:
        f.write(report)

if __name__ == '__main__':
    import sys
    project_path = sys.argv[1] if len(sys.argv) > 1 else '.'
    main(project_path)
