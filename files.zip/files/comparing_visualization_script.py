import matplotlib.pyplot as plt
import pandas as pd

# Consolidated Data
data = {
    "Project": ["Flask", "Requests", "Markdown"],
    "Total Modules": [49, 47, 113],
    "High Cohesion": [33, 12, 64],
    "Low Cohesion": [16, 35, 49],
    "Fan-In": [138, 100, 65],
    "Fan-Out": [85, 37, 72]
}

df = pd.DataFrame(data)

# Cohesion Comparison
df[["Project", "High Cohesion", "Low Cohesion"]].set_index("Project").plot(
    kind="bar", stacked=True
)
plt.title("Cohesion Comparison Across Projects")
plt.ylabel("Number of Modules")
plt.xlabel("Projects")
plt.legend(title="Cohesion Type")
plt.show()

# Coupling Analysis
df[["Project", "Fan-In", "Fan-Out"]].set_index("Project").plot(kind="bar")
plt.title("Coupling Analysis Across Projects")
plt.ylabel("Count")
plt.xlabel("Projects")
plt.legend(title="Coupling Type")
plt.show()

# Module Count
df[["Project", "Total Modules"]].set_index("Project").plot(kind="bar")
plt.title("Total Module Count Across Projects")
plt.ylabel("Total Modules")
plt.xlabel("Projects")
plt.show()
